"""train.py - trains the hotel cancellation model and saves it to model/.
Run:  python train.py   (hotel_bookings.csv must be in the same folder)
Creates: model/hotel_cancel_pipeline.joblib, model/meta.json, model/results_table.csv, figures/*.png"""

import matplotlib
matplotlib.use("Agg")  # save figures to files instead of opening windows



# ============================================================
# 🏨 Hotel Revenue Protection: Booking Cancellation Predictor
# ============================================================

import warnings; warnings.filterwarnings('ignore')
import numpy as np, pandas as pd, matplotlib.pyplot as plt, seaborn as sns, joblib, json, os, time
from sklearn.model_selection import train_test_split, StratifiedKFold, RandomizedSearchCV, GridSearchCV, cross_val_predict, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import (roc_auc_score, average_precision_score, f1_score, precision_score, recall_score,
                             accuracy_score, confusion_matrix, ConfusionMatrixDisplay, RocCurveDisplay,
                             PrecisionRecallDisplay, classification_report, precision_recall_curve)
from sklearn.inspection import permutation_importance
from hotel_features import build_features, NUM_FEATURES, CAT_FEATURES, LEAKAGE_COLS, EXCLUDED_COLS, MONTHS

SEED = 42
sns.set_theme(style='whitegrid', context='notebook')
os.makedirs('figures', exist_ok=True)
DATA = 'hotel_bookings.csv'   # download from the Kaggle link above and put it next to this notebook
raw = pd.read_csv(DATA)
print(raw.shape)


# ============================================================
# 2 · Data understanding
# ============================================================

print(f"Rows: {raw.shape[0]:,}  |  Columns: {raw.shape[1]}")
print(f"Period: {raw.arrival_date_year.min()} → {raw.arrival_date_year.max()}  |  Hotels: {raw.hotel.unique().tolist()}")
print(raw.head())


# ============================================================
# **Column dictionary (main groups)**
# ============================================================

info = pd.DataFrame({'dtype': raw.dtypes.astype(str), 'missing': raw.isna().sum(), 'missing_%': (raw.isna().mean()*100).round(2), 'n_unique': raw.nunique()})
print(info)
print("\nString 'NULL' placeholders:", {c: int((raw[c]=='NULL').sum()) for c in raw.columns if raw[c].dtype==object or str(raw[c].dtype)=='str' if (raw[c]=='NULL').sum()>0})
print(f"\nExact duplicate rows: {raw.duplicated().sum():,} ({raw.duplicated().mean():.1%})")
print("Class balance (raw):"); print(raw.is_canceled.value_counts(normalize=True).round(3))


# ============================================================
# Cleaning decisions
# ============================================================

df = raw.drop_duplicates().copy()
df = df[(df.adults + df.children.fillna(0) + df.babies) > 0].reset_index(drop=True)
print(f"After cleaning: {df.shape[0]:,} rows (removed {raw.shape[0]-df.shape[0]:,})")
print(f"Cancellation rate after cleaning: {df.is_canceled.mean():.1%}")


# ============================================================
# 3 · Exploratory data analysis
# ============================================================

fig, ax = plt.subplots(1, 3, figsize=(16, 4))
df.is_canceled.value_counts().rename({0:'Stayed',1:'Cancelled'}).plot.bar(ax=ax[0], color=['#2a9d8f','#e76f51'], rot=0); ax[0].set_title('Target balance')
sns.histplot(df.lead_time, bins=50, ax=ax[1], color='#264653'); ax[1].set_title('Lead time (days)')
sns.histplot(df.adr.clip(0,500), bins=50, ax=ax[2], color='#e9c46a'); ax[2].set_title('ADR (clipped at 500)')
plt.tight_layout(); plt.savefig('figures/01_univariate.png', dpi=130); plt.close()
print(df[['lead_time','adr','stays_in_week_nights','stays_in_weekend_nights','previous_cancellations']].describe().round(1))

fig, ax = plt.subplots(2, 3, figsize=(18, 9))
d = df.copy()
d['lead_bin'] = pd.cut(d.lead_time, [-1,7,30,90,180,365,1000], labels=['0-7','8-30','31-90','91-180','181-365','365+'])
d.groupby('lead_bin', observed=True).is_canceled.mean().mul(100).plot.bar(ax=ax[0,0], color='#e76f51', rot=0); ax[0,0].set_title('Cancel rate % by lead time (days)')
d.groupby('market_segment').is_canceled.mean().mul(100).sort_values().plot.barh(ax=ax[0,1], color='#e76f51'); ax[0,1].set_title('Cancel rate % by market segment')
d.groupby('hotel').is_canceled.mean().mul(100).plot.bar(ax=ax[0,2], color='#e76f51', rot=0); ax[0,2].set_title('Cancel rate % by hotel')
d.groupby('arrival_date_month').is_canceled.mean().reindex(MONTHS).mul(100).plot.bar(ax=ax[1,0], color='#e76f51'); ax[1,0].set_title('Cancel rate % by arrival month')
d.groupby('total_of_special_requests').is_canceled.mean().mul(100).plot.bar(ax=ax[1,1], color='#e76f51', rot=0); ax[1,1].set_title('Cancel rate % by # special requests')
top = d.country.value_counts().head(10).index
d[d.country.isin(top)].groupby('country').is_canceled.mean().mul(100).sort_values().plot.barh(ax=ax[1,2], color='#e76f51'); ax[1,2].set_title('Cancel rate % — top 10 countries by volume')
plt.tight_layout(); plt.savefig('figures/02_bivariate.png', dpi=130); plt.close()

fig, ax = plt.subplots(1, 2, figsize=(16, 6))
num = ['is_canceled','lead_time','adr','total_of_special_requests','previous_cancellations',
       'previous_bookings_not_canceled','is_repeated_guest','days_in_waiting_list','adults','stays_in_week_nights','stays_in_weekend_nights']
sns.heatmap(df[num].corr(), annot=True, fmt='.2f', cmap='RdBu_r', center=0, ax=ax[0], cbar=False, annot_kws={'size':7}); ax[0].set_title('Correlation matrix')
x = df.assign(lead_bin=pd.cut(df.lead_time,[-1,30,90,365,1000],labels=['≤30','31-90','91-365','365+']))
piv = x.pivot_table(index='market_segment', columns='lead_bin', values='is_canceled', aggfunc='mean', observed=True).mul(100)
sns.heatmap(piv, annot=True, fmt='.0f', cmap='YlOrRd', ax=ax[1]); ax[1].set_title('Cancel rate %: market segment × lead time')
plt.tight_layout(); plt.savefig('figures/03_multivariate.png', dpi=130); plt.close()

s = {}
lb = d.groupby('lead_bin', observed=True).is_canceled.mean()
ms = d.groupby('market_segment').is_canceled.agg(['mean','size']).query('size>500')
print(f"Lead time:   {lb.iloc[0]:.1%} cancel for 0-7 days  →  {lb.iloc[-1]:.1%} for 365+ days")
print("Market segment (n>500):"); print((ms['mean']*100).round(1).sort_values(ascending=False).to_string())
sr = d.groupby(d.total_of_special_requests>0).is_canceled.mean()
print(f"Special requests: {sr[False]:.1%} cancel with none vs {sr[True]:.1%} with ≥1")
pc = d.groupby(d.previous_cancellations>0).is_canceled.agg(['mean','size']); print("Previous cancellations (False/True):"); print(pc.round(3).to_string())
ht = d.groupby('hotel').is_canceled.mean(); print(ht.round(3).to_dict())
rg = d.groupby('is_repeated_guest').is_canceled.mean(); print(f"Repeat guest: {rg[1]:.1%} vs new {rg[0]:.1%}")


# ============================================================
# 💡 EDA insights
# ============================================================


# ============================================================
# 4 · Leakage check (why some columns are dropped)
# ============================================================

print("Outcome vs reservation_status:"); print(pd.crosstab(df.reservation_status, df.is_canceled))
print("\nCancel rate by deposit_type:"); print(df.groupby('deposit_type').is_canceled.agg(['mean','size']).round(3))
pk = df.groupby(df.required_car_parking_spaces>0).is_canceled.agg(['mean','size']); print("\nCancel rate by parking requested (False/True):"); print(pk.round(4))
print("Cancel rate by booking_changes>0 (False/True):"); print(df.groupby(df.booking_changes>0).is_canceled.mean().round(3).to_dict())


# ============================================================
# - `reservation_status` / `reservation_status_date` **are the outcome itself** (Canceled / No-Show ⇒ `is_canceled = 1`; Check-Out ⇒ 0) → removed.
# ============================================================

y_all = df.is_canceled; X_all = df.drop(columns='is_canceled')
Xa, Xb, ya, yb = train_test_split(X_all, y_all, test_size=0.2, stratify=y_all, random_state=SEED)
def quick_auc(extra_cat):
    cats = CAT_FEATURES + extra_cat
    def fe(d):
        out = build_features(d)
        for c in extra_cat: out[c] = d[c].values
        return out
    pre = ColumnTransformer([('n', SimpleImputer(strategy='median'), NUM_FEATURES),
        ('c', OneHotEncoder(handle_unknown='infrequent_if_exist', min_frequency=0.01, sparse_output=False), cats)])
    p = Pipeline([('fe', FunctionTransformer(fe)), ('pre', pre), ('m', HistGradientBoostingClassifier(random_state=SEED))]).fit(Xa, ya)
    return roc_auc_score(yb, p.predict_proba(Xb)[:,1])
print(f"ROC-AUC without deposit_type: {quick_auc([]):.4f}")
print(f"ROC-AUC with    deposit_type: {quick_auc(['deposit_type']):.4f}   ← (shown only for comparison; not used)")


# ============================================================
# 5 · Preprocessing & pipeline (no leakage)
# ============================================================

y = df.is_canceled; X = df.drop(columns=['is_canceled'] + LEAKAGE_COLS + EXCLUDED_COLS)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)
print(f"Train: {X_train.shape}  cancel rate {y_train.mean():.3f}  |  Test: {X_test.shape}  cancel rate {y_test.mean():.3f}")

def make_pipe(model):
    pre = ColumnTransformer([
        ('num', Pipeline([('imp', SimpleImputer(strategy='median')), ('sc', StandardScaler())]), NUM_FEATURES),
        ('cat', OneHotEncoder(handle_unknown='infrequent_if_exist', min_frequency=0.01, sparse_output=False), CAT_FEATURES)])
    return Pipeline([('fe', FunctionTransformer(build_features)), ('pre', pre), ('model', model)])
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)


# ============================================================
# 6 · Modeling — baseline + 3 algorithms, then tuning
# ============================================================

candidates = {
  'Baseline (majority class)': DummyClassifier(strategy='most_frequent'),
  'Logistic Regression': LogisticRegression(max_iter=1000, class_weight='balanced'),
  'Random Forest': RandomForestClassifier(n_estimators=150, min_samples_leaf=3, max_samples=0.5, n_jobs=-1, class_weight='balanced_subsample', random_state=SEED),
  'Gradient Boosting (HistGB)': HistGradientBoostingClassifier(random_state=SEED),
}
rows = []
for name, m in candidates.items():
    t = time.time()
    s = cross_val_score(make_pipe(m), X_train, y_train, cv=cv, scoring='roc_auc', n_jobs=1)
    rows.append({'model': name, 'CV ROC-AUC (mean)': s.mean(), 'std': s.std(), 'sec': time.time()-t}); print(rows[-1])
print(pd.DataFrame(rows).round(4))

# Hyperparameter tuning — training data only, 3-fold CV, optimising ROC-AUC
searches = {}
t = time.time()
searches['Logistic Regression'] = GridSearchCV(make_pipe(LogisticRegression(max_iter=1000, class_weight='balanced')),
    {'model__C': [0.01, 0.1, 1, 10]}, cv=3, scoring='roc_auc', n_jobs=1).fit(X_train, y_train)
print('LR  done', round(time.time()-t), 's  best', searches['Logistic Regression'].best_params_, round(searches['Logistic Regression'].best_score_, 4))
t = time.time()
searches['Random Forest'] = RandomizedSearchCV(make_pipe(RandomForestClassifier(n_estimators=150, max_samples=0.5, n_jobs=-1, class_weight='balanced_subsample', random_state=SEED)),
    {'model__max_depth': [12, 18, 25, None], 'model__min_samples_leaf': [1, 3, 5, 10], 'model__max_features': ['sqrt', 0.3, 0.5]},
    n_iter=6, cv=3, scoring='roc_auc', n_jobs=1, random_state=SEED).fit(X_train, y_train)
print('RF  done', round(time.time()-t), 's  best', searches['Random Forest'].best_params_, round(searches['Random Forest'].best_score_, 4))
t = time.time()
searches['Gradient Boosting (HistGB)'] = RandomizedSearchCV(make_pipe(HistGradientBoostingClassifier(random_state=SEED)),
    {'model__learning_rate': [0.03, 0.05, 0.1, 0.15], 'model__max_leaf_nodes': [15, 31, 63], 'model__min_samples_leaf': [20, 50, 100],
     'model__l2_regularization': [0, 0.1, 1.0], 'model__max_iter': [200, 400]},
    n_iter=8, cv=3, scoring='roc_auc', n_jobs=1, random_state=SEED).fit(X_train, y_train)
print('HGB done', round(time.time()-t), 's  best', searches['Gradient Boosting (HistGB)'].best_params_, round(searches['Gradient Boosting (HistGB)'].best_score_, 4))


# ============================================================
# 7 · Final evaluation on the untouched test set
# ============================================================

def metrics(y_true, proba, thr=0.5):
    pred = (proba >= thr).astype(int)
    return {'ROC-AUC': roc_auc_score(y_true, proba), 'PR-AUC': average_precision_score(y_true, proba),
            'Accuracy': accuracy_score(y_true, pred), 'Precision': precision_score(y_true, pred, zero_division=0),
            'Recall': recall_score(y_true, pred), 'F1': f1_score(y_true, pred)}
res = {}
base = make_pipe(DummyClassifier(strategy='most_frequent')).fit(X_train, y_train)
res['Baseline (majority class)'] = metrics(y_test, base.predict_proba(X_test)[:,1])
for n, s in searches.items():
    res[n + ' (tuned)'] = metrics(y_test, s.best_estimator_.predict_proba(X_test)[:,1])
results = pd.DataFrame(res).T.round(4); print(results)

best_name = max(searches, key=lambda k: searches[k].best_score_)     # chosen on CV score, NOT on test score
best = searches[best_name].best_estimator_
print('Selected by cross-validation:', best_name, '| CV ROC-AUC', round(searches[best_name].best_score_, 4))
# decision threshold chosen on out-of-fold predictions of the TRAIN set (maximise F1) — test set stays untouched
oof = cross_val_predict(best, X_train, y_train, cv=cv, method='predict_proba')[:,1]
p, r, th = precision_recall_curve(y_train, oof); f1s = 2*p*r/(p+r+1e-9)
THR = float(th[np.argmax(f1s[:-1])]); print(f'Decision threshold (from train OOF, max F1): {THR:.3f}')
proba = best.predict_proba(X_test)[:,1]; pred = (proba >= THR).astype(int)
print(pd.Series(metrics(y_test, proba, THR)).round(4).to_string()); print(); print(classification_report(y_test, pred, target_names=['Stayed','Cancelled']))

fig, ax = plt.subplots(1, 3, figsize=(17, 4.8))
ConfusionMatrixDisplay(confusion_matrix(y_test, pred), display_labels=['Stayed','Cancelled']).plot(ax=ax[0], cmap='Blues', colorbar=False); ax[0].set_title(f'Confusion matrix (threshold {THR:.2f})')
RocCurveDisplay.from_predictions(y_test, proba, ax=ax[1], name=best_name); ax[1].plot([0,1],[0,1],'k--', lw=.8); ax[1].set_title('ROC curve')
PrecisionRecallDisplay.from_predictions(y_test, proba, ax=ax[2], name=best_name); ax[2].axhline(y_test.mean(), color='k', ls='--', lw=.8); ax[2].set_title('Precision–Recall curve')
plt.tight_layout(); plt.savefig('figures/04_evaluation.png', dpi=130); plt.close()

# Which features drive predictions? (permutation importance, 6k test rows)
idx = np.random.RandomState(SEED).choice(len(X_test), 6000, replace=False)
pi = permutation_importance(best, X_test.iloc[idx], y_test.iloc[idx], scoring='roc_auc', n_repeats=3, random_state=SEED, n_jobs=1)
imp = pd.Series(pi.importances_mean, index=X_test.columns).sort_values(ascending=False)
raw_cols_imp = imp.head(12)[::-1]
raw_cols_imp.plot.barh(figsize=(8,5), color='#264653'); plt.title('Permutation importance (drop in ROC-AUC)'); plt.tight_layout(); plt.savefig('figures/05_importance.png', dpi=130); plt.close()
print(imp.head(8).round(4))

# Error analysis
ea = X_test.copy(); ea['y'] = y_test.values; ea['pred'] = pred; ea['proba'] = proba
ea['type'] = np.select([(ea.y==1)&(ea.pred==0), (ea.y==0)&(ea.pred==1), (ea.y==1)&(ea.pred==1)], ['FN (missed cancel)','FP (false alarm)','TP'], 'TN')
print(ea.type.value_counts().to_string()); print()
ea['lead_bin'] = pd.cut(ea.lead_time, [-1,7,30,90,180,365,1000], labels=['0-7','8-30','31-90','91-180','181-365','365+'])
for col in ['market_segment', 'lead_bin', 'hotel']:
    t = ea.groupby(col, observed=True).apply(lambda g: pd.Series({'n': len(g), 'cancel_rate': g.y.mean(), 'recall': g[g.y==1].pred.mean(), 'precision': g[g.pred==1].y.mean() if (g.pred==1).any() else np.nan}))
    print(f'--- by {col}'); print(t.round(3).to_string()); print()
# calibration by probability decile
ea['decile'] = pd.qcut(ea.proba, 10, duplicates='drop'); cal = ea.groupby('decile', observed=True).agg(mean_pred=('proba','mean'), actual=('y','mean'), n=('y','size')); print('Calibration (by decile):'); print(cal.round(3).to_string())


# ============================================================
# Error analysis — what the model gets wrong
# ============================================================


# ============================================================
# 8 · Business insight — from probability to deposit policy
# ============================================================

LOW, HIGH = 0.30, 0.60
ea['risk'] = pd.cut(ea.proba, [-0.01, LOW, HIGH, 1.01], labels=['Low (<30%)', 'Medium (30-60%)', 'High (>60%)'])
ea['revenue'] = (ea.adr.clip(0, 1000) * ea.total_nights if 'total_nights' in ea else ea.adr.clip(0,1000) * (ea.stays_in_weekend_nights + ea.stays_in_week_nights))
tier = ea.groupby('risk', observed=True).agg(bookings=('y','size'), actual_cancel_rate=('y','mean'), total_revenue=('revenue','sum'))
tier['share_of_bookings'] = tier.bookings / tier.bookings.sum()
tier['revenue_lost_to_cancellations'] = ea[ea.y==1].groupby('risk', observed=True).revenue.sum()
tier['policy'] = ['No deposit', 'Partial deposit (e.g. first night)', 'Full / non-refundable deposit']
print(tier.round(3))

# Illustrative revenue-protection estimate on the test set (assumption: guests in the tier pay a deposit
# that the hotel keeps if they cancel — 100% for High tier, 30% for Medium tier; these rates are ASSUMPTIONS, not data).
lost_total = ea[ea.y==1].revenue.sum()
prot_high = ea[(ea.y==1)&(ea.risk=='High (>60%)')].revenue.sum() * 1.0
prot_med  = ea[(ea.y==1)&(ea.risk=='Medium (30-60%)')].revenue.sum() * 0.30
print(f"Revenue sitting in cancelled bookings (test set): {lost_total:,.0f}")
print(f"Retained if High-tier pays full deposit + Medium-tier pays 30%: {prot_high+prot_med:,.0f}  ({(prot_high+prot_med)/lost_total:.1%} of cancelled revenue)")
print(f"High tier covers {(ea.risk=='High (>60%)').mean():.1%} of bookings, with actual cancel rate {ea[ea.risk=='High (>60%)'].y.mean():.1%}")


# ============================================================
# Recommendations & limitations
# ============================================================


# ============================================================
# 9 · Save the pipeline for the web app
# ============================================================

final = best.fit(X_train, y_train)   # already fitted on train; refit on train only to keep the test set honest
os.makedirs('model', exist_ok=True)
joblib.dump(final, 'model/hotel_cancel_pipeline.joblib', compress=3)
top_countries = df.country.value_counts().head(40).index.tolist()
meta = {'model': best_name, 'threshold': THR, 'low': LOW, 'high': HIGH,
        'metrics_test': {k: round(float(v), 4) for k, v in metrics(y_test, proba, THR).items()},
        'baseline_test': {k: round(float(v), 4) for k, v in res['Baseline (majority class)'].items()},
        'n_train': int(len(X_train)), 'n_test': int(len(X_test)), 'cancel_rate': round(float(y.mean()), 4),
        'choices': {c: sorted(df[c].dropna().astype(str).unique().tolist()) for c in ['hotel','meal','market_segment','distribution_channel','reserved_room_type','customer_type']},
        'top_countries': top_countries,
        'ranges': {'lead_time_max': int(df.lead_time.max()), 'adr_median': float(df.adr.median())}}
json.dump(meta, open('model/meta.json', 'w'), indent=2)
results.to_csv('model/results_table.csv')
# sanity check: reload and predict one raw row
chk = joblib.load('model/hotel_cancel_pipeline.joblib'); print(chk.predict_proba(X_test.head(3))[:,1], proba[:3])
print('model size MB:', os.path.getsize('model/hotel_cancel_pipeline.joblib')/1e6)


# ============================================================
# ---
# ============================================================